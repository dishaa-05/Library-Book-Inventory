
//Manages the collection of books in the library
import java.util.ArrayList;

public class Library {

    // Stores book objects in memory
    private ArrayList<Book> books = new ArrayList<>();

    // method to find a book using isbn
    private Book findBookByIsbn(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    // method to add a new book
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully");
    }

    // method to display all books
    public void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available in the library");
            return;
        }

        for (Book book : books) {
            book.displayBook();
            System.out.println("--------------------");
        }

    }

    // method to update book details using isbn
    public void updateBook(String isbn, String newTitle, String newAuthor, int newYear) {
        Book book = findBookByIsbn(isbn);
        if (book == null) {
            System.out.println("Book not found");
            return;
        }
        book.setTitle(newTitle);
        book.setAuthor(newAuthor);
        book.setPublicationYear(newYear);
        System.out.println("Book updated successfully");

    }

    // method to delete book details using isbn
    public void deleteBook(String isbn) {
        Book book = findBookByIsbn(isbn);
        if (book == null) {
            System.out.println("Book not found");
            return;

        }
        books.remove(book);
        System.out.println("Book deleted successfully");

    }

}
