@echo off
java -jar target\library-book-inventory-1.0-SNAPSHOT.jar
pause